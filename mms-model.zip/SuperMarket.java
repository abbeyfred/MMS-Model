 public class SuperMarket {

    private String name;
    private String email;
    private String password;
    private Memberships memberships;
    private MMSLog mmsLog;

    public SuperMarket(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
        memberships = new Memberships();
        mmsLog = new MMSLog();
    }
    
    public boolean hasEmail(String email) {
        return email.equals(this.email);
    }

    public boolean hasPassword(String password) {
        return password.equals(this.password);
    }

    public void useAdminMenu() {
        help();
        char choice;
        while((choice = Utils.choice("Session Admin: " + name + " - Menu Commands (C/R/U/D/V/M/X)")) != 'X') {
            switch(choice) {
                case 'C' : addMembership(); break;
                case 'R' : viewMembership(); break;
                case 'U' : updateMembership(); break;
                case 'D' : deleteMembership(); break;
                case 'V' : viewMemberships(); break;
                case 'M' : useMMSMenu(); break;
                default : help(); break;
            }
        }
        System.out.println();
        System.out.println("MMS Management System:");
    }

    private void help() {
        System.out.println("Admin Menu: ");
        System.out.println("C- Add Membership");
        System.out.println("R- View Membership");
        System.out.println("U- Update Membership");
        System.out.println("D- Delete Membership");
        System.out.println("V- View Memberships");
        System.out.println("M- MMS Menu");
        System.out.println("X- Logout");
    }

    private void addMembership() {
        memberships.addMembership();
    }
    
    private void viewMembership() {
        String name = Utils.string("Name");
        Membership membership = memberships.membershipWithName(name);
        if(membership != null) {
            Utils.membershipHeader();
            membership.viewMembership();
            Utils.membershipTableEnd();
        }
        else {
            System.out.println(name + " record does not exist!");
        }
    }

    private void updateMembership() {
        String name = Utils.string("Name");
        Membership membership = memberships.membershipWithName(name);
        if(membership != null) {
            System.out.println("Updating " + name + " record: ");
            membership.updateMembership(Utils.string("Name"), Utils.string("Email"), Utils.string("Phone"), Utils.string("Address"), Utils.string("ID"), Utils.amount("expense"));
            System.out.println(name + " record has been updated.");
        }
        else {
            System.out.println(name + " record does not exist!");
        }
    }

    private void deleteMembership() {
        String name = Utils.string("Name");
        Membership membership = memberships.membershipWithName(name);
        if(membership != null) {
            memberships.deleteMembership(membership);
            System.out.println(name + " record has been deleted.");
        }
        else {
            System.out.println(name + " record does not exist!");
        }
    }

    private void viewMemberships() {
        Utils.membershipHeader();
        memberships.viewMemberships();
        Utils.membershipTableEnd();
    }
    
    private void useMMSMenu() {
        MMS mms = new MMS(this, memberships);
        mms.useMMSMenu();
    }

    public String getName() {
        return this.name;
    }
    
    public void archiveMMSReport(SuperMarket superMarket, Memberships memberships) {
        mmsLog.archiveMMSReport(superMarket, memberships);
    }
    
    public void showMMSLog(SuperMarket superMarket) {
        mmsLog.showMMSLog(superMarket);
    }

    public MMS mms(String enteredID, SuperMarket superMarket) {
        return mmsLog.mms(enteredID, superMarket);
    }

    public void retrieveMMSReport(MMS mms) {
        mmsLog.retrieveMMSReport(mms);
    }

    @Override
    public String toString() {
        return this.name;
    }

}
