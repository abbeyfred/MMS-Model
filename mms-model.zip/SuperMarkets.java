import java.util.ArrayList;

public class SuperMarkets {

    private ArrayList<SuperMarket> superMarkets = new ArrayList<SuperMarket>();

    public SuperMarkets() {
        superMarkets.add(new SuperMarket("John Smith", "john.smith@uts.com", "user222"));
        superMarkets.add(new SuperMarket("Jane Tyler", "jane.tyler@uts.com", "super123"));
    }

    public SuperMarket superMarket(String email) {
        for(SuperMarket superMarket : superMarkets) {
            if(superMarket.hasEmail(email)) {
                return superMarket;
            }
        }
        return null;
    }

}
