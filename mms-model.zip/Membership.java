public class Membership {
    
    private String name;
    private String email;
    private String phone;
    private String address;
    private String id;
    private double expense;
    private String type;
    private int payPerCredit;
    private double deductionRate;
    private double gasDeductionRate;
    private double totalCredits;
    private int dollarAvailable;
    private SuperMarket superMarket;

    public Membership(String name, String email, String phone, String address, String id, double expense) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.id = id;
        this.expense = expense;
        this.type = membershipType(this.expense);
        switch(this.type) {
            case "Bronze" : this.payPerCredit = 20; this.deductionRate = 0.05; this.gasDeductionRate = 0.1; break;
            case "Silver" : this.payPerCredit = 10; this.deductionRate = 0.1; this.gasDeductionRate = 0.15; break;
            case "Gold" : this.payPerCredit = 8; this.deductionRate = 0.15; this.gasDeductionRate = 0.2; break;
            case "Diamond" : this.payPerCredit = 6; this.deductionRate = 0.2; this.gasDeductionRate = 0.25; break;
            default : this.payPerCredit = 4; this.deductionRate = 0.25; this.gasDeductionRate = 0.3; break;
        }
        this.totalCredits = (double)this.payPerCredit * this.expense;
        this.dollarAvailable = (int)this.totalCredits / 200;
        this.superMarket = superMarket;
    }
    
    private String membershipType(double expense) {
        if(expense < 500) {
             return "Bronze";
        }
        else if(expense >= 500 && expense < 1500) {
            return "Silver";
        }
        else if(expense >= 1500 && expense < 3000) {
            return "Gold";
        }
        else if(expense >= 3000 && expense < 5000) {
            return "Diamond";
        }
        else {
            return "Platinum";
        }
    }

    public boolean hasEmail(String email) {
        return email.equals(this.email);
    }

    public boolean hasName(String name) {
        return name.equals(this.name);
    }

    public void viewMembership() {
        System.out.format(Utils.membershipFormat, name, email, phone, type);
    }

    public void updateMembership(String name, String email, String phone, String address, String id, double expense) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.id = id;
        if(expense > 0) {
            this.expense += expense;
            this.type = membershipType(this.expense);
        }
        else {
            this.expense -= expense;
            this.type = membershipType(this.expense);
        }
    }

    public String getName() {
        return this.name;
    }

    public double getExpense() {
        return this.expense;
    }

    public double getTotalCredits() {
        return this.totalCredits;
    }

    public int getDollarAvailable() {
        return this.dollarAvailable;
    }

    public String getType() {
        return this.type;
    }

    public int getPayPerCredit() {
        return this.payPerCredit;
    }

    public double getDeductionRate() {
        return this.deductionRate;
    }

    public double getGasDeductionRate() {
        return this.gasDeductionRate;
    }

}
