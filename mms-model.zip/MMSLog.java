import java.util.ArrayList;

public class MMSLog {
    
    private ArrayList<MMS> mmsLog = new ArrayList<MMS>();
    
    public MMSLog() {

    }

    public void archiveMMSReport(SuperMarket superMarket, Memberships memberships) {
        mmsLog.add(new MMS(superMarket, memberships));
        System.out.println("MMS record is created as:" + superMarket.getName() + mmsLog.size());
    }

    public void showMMSLog(SuperMarket superMarket) {
        if(mmsLog.size() == 1) {
            System.out.format(Utils.logFormat, "MMS " + mmsLog.size(), superMarket.getName() + mmsLog.size());
        }
        else if(mmsLog.size() == 2) {
            int count = 0;
            for(MMS mms : mmsLog) {
                if(("" + mmsLog.get(0)).equals("" + mmsLog.get(1))) {
                    count++;
                    System.out.format(Utils.logFormat, "MMS " + count, superMarket.getName() + mmsLog.size());
                }
                else {
                    count++;
                    System.out.format(Utils.logFormat, "MMS " + count, superMarket.getName() + count);
                }
            }
        }
        else {

        }
    }

    public MMS mms(String enteredID, SuperMarket superMarket) {
        int index = index(recordIDs(superMarket), enteredID);
        if(index != -1) {
            for(MMS mms : mmsLog) {
                return mmsLog.get(index);
            }
        }
        return null;
    }

    private int index(ArrayList<String> recordIDs, String enteredID) {
        for(String recordID : recordIDs) {
            if(recordID.equals(enteredID)) {
                return recordIDs.indexOf(recordID);
            }
        }
        return -1;
    }

    private ArrayList<String> recordIDs(SuperMarket superMarket) {
        ArrayList<String> recordIDs = new ArrayList<String>();
        if(mmsLog.size() == 1) {
            recordIDs.add(superMarket.getName() + mmsLog.size());
        }
        else if(mmsLog.size() == 2) {
            int count = 0;
            for(MMS mms : mmsLog) {
                if(("" + mmsLog.get(0)).equals("" + mmsLog.get(1))) {
                    count++;
                    recordIDs.add(superMarket.getName() + mmsLog.size());
                }
                else {
                    count++;
                    recordIDs.add(superMarket.getName() + count);
                }
            }
        }
        else {

        }
        return recordIDs;
    }

    public void retrieveMMSReport(MMS mms) {
        mms.viewMMSReport();
    }
    
}
