import java.util.ArrayList;

public class Memberships {

    private ArrayList<Membership> memberships = new ArrayList<Membership>();

    public Memberships() {
        memberships.add(new Membership("Thomas Muller", "thomas.muller@uts.com", "99991111", "3 Byern St. Sydney 2001", "13697480", 2134.5));
        memberships.add(new Membership("Alice Stefan", "alice.stefan@uts.com", "88881111", "24 Pitt St. Sydney 2001", "14517880", 4512.2));
        memberships.add(new Membership("Lucy Lu", "lucy.lu@uts.com", "98981100", "11 Hunter St. Sydney 2100", "13267102", 158.4));
        memberships.add(new Membership("Andreas Brehme", "andreas.b@uts.com", "90001222", "91 Sussex St. Sydney 2100", "13678020", 7596.3));
        memberships.add(new Membership("Ruddy Voller", "ruddy.v@uts.com", "98980000", "15 Stan St. Sydney 2100", "13972870", 1100.0));
        memberships.add(new Membership("Monica Shwarz", "monica.s@uts.com", "92241188", "155 Jones St. Sydney 2001", "13859610", 6741.2));
    }

    public void addMembership() {
        String name = Utils.string("Name");
        String email = Utils.string("Email");
        Membership membership = membershipWithEmail(email);
        if(membership == null) {
            memberships.add(new Membership(name, email, Utils.string("Phone"), Utils.string("Address"), Utils.string("ID"), Utils.amount("expense")));
            System.out.println(name + " record has been created.");
        }
        else {
            System.out.println("Membership with that email already exists.");
        }
    }

    private Membership membershipWithEmail(String email) {
        for(Membership membership : memberships) {
            if(membership.hasEmail(email)) {
                return membership;
            }
        }
        return null;
    }

    public Membership membershipWithName(String name) {
        for(Membership membership : memberships) {
            if(membership.hasName(name)) {
                return membership;
            }
        }
        return null;
    }
    
    public void deleteMembership(Membership membershipToDelete) {
        for(Membership membership : memberships) {
            if(membership.equals(membershipToDelete)) {
                memberships.remove(membership);
                break;
            }
        }
    }
    
    public void viewMemberships() {
        for(Membership membership : memberships) {
            membership.viewMembership();
        }
    }

    public ArrayList<Membership> getMemberships() {
        return this.memberships;
    }

    public int getSize() {
        return memberships.size();
    }

}
