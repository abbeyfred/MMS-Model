public class MMSlip {

    private String name;
    private String type;
    private double totalCredits;
    private double gasDeductionRate;
    private int dollarAvailable;
    private double deductionRate;
    private double payPerCredit;
    private double expense;
    
    public MMSlip(Membership membership) {
        this.name = membership.getName();
        this.expense = membership.getExpense();
        this.totalCredits = membership.getTotalCredits();
        this.dollarAvailable = membership.getDollarAvailable();
        this.type = membership.getType();
        this.payPerCredit = membership.getPayPerCredit();
        this.deductionRate = membership.getDeductionRate();
        this.gasDeductionRate = membership.getGasDeductionRate();
    }

    public boolean hasName(String name) {
        return name.equals(this.name);
    }

    public void findSlipDetails() {
        System.out.format(Utils.mmsFormat, name, expense, totalCredits, dollarAvailable, type);
    }

    @Override
    public String toString() {
        return "" + this.name + this.expense + this.totalCredits + this.dollarAvailable + this.type;
    }

}
