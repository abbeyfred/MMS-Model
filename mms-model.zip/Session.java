public class Session {
    
    private SuperMarkets superMarkets;
    
    public static void main(String[] args) {
        new Session().use();
    }

    public Session() {
        superMarkets = new SuperMarkets();
    }

    public void use() {
        help();
        char choice;
        while((choice = Utils.choice("Command (L/X)")) != 'X') {
            switch(choice) {
                case 'L' : login(); break;
                default : help(); break;
            }
        }
        System.out.println();
        System.out.println("Session Terminated!");
    }

    private void help() {
        System.out.println("Membership Management System:");
        System.out.println("L- Login");
        System.out.println("X- Exit");
    }

    private void login() {
        SuperMarket superMarket = superMarkets.superMarket(Utils.string("Email"));
        if(superMarket != null) {
            if(superMarket.hasPassword(Utils.string("Password"))) {
                superMarket.useAdminMenu();
            }
            else {
                System.out.println("Incorrect SuperMarket details!");
            }
        }
        else {
            System.out.println("Incorrect SuperMarket details!");
        }
    }

}
