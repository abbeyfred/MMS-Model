import java.util.ArrayList;

public class MMS {
    
    private SuperMarket superMarket;
    private Memberships memberships;
    private ArrayList<MMSlip> mmSlips = new ArrayList<MMSlip>();
    private String name;
    private double expense;
    private double totalCredits;
    private double dollarAvailable;
    private double gasDeductionRate;
    private double deductionRate;
    private double payPerCredit;

    public MMS(SuperMarket superMarket, Memberships memberships) {
        this.superMarket = superMarket;
        this.memberships = memberships;
        for(Membership membership : memberships.getMemberships()) {
            mmSlips.add(new MMSlip(membership));
        }
        this.name = superMarket.getName();
        this.expense = totalExpense();
        this.totalCredits = totalCredits();
        this.dollarAvailable = totalDollarAvailable();
        this.gasDeductionRate = totalGasDeductionRate();
        this.deductionRate = totalDeductionRate();
        this.payPerCredit = totalPayPerCredit();
    }

    private double totalExpense() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getExpense();
        }
        return sum;
    }

    private double totalCredits() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getTotalCredits();
        }
        return sum;
    }

    private double totalDollarAvailable() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getDollarAvailable();
        }
        return sum;
    }

    private double totalGasDeductionRate() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getGasDeductionRate();
        }
        return sum;
    }

    private double totalDeductionRate() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getDeductionRate();
        }
        return sum;
    }

    private double totalPayPerCredit() {
        double sum = 0;
        for(Membership membership : memberships.getMemberships()) {
            sum += membership.getPayPerCredit();
        }
        return sum;
    }

    public void useMMSMenu() {
        help();
        char choice;
        while((choice = Utils.choice("Session Admin: " + name + " - Menu Commands (F/V/A/R/S/X)")) != 'X') {
            switch(choice) {
                case 'F' : findSlipDetails(); break;
                case 'V' : viewMMSReport(); break;
                case 'A' : archiveMMSReport(); break;
                case 'R' : retrieveMMSReport(); break;
                case 'S' : showMMSLog(); break;
                default : help(); break;
            }
        }
        System.out.println();
        System.out.println("SuperMarket Menu:");
    }

    private void help() {
        System.out.println("MMS Menu: ");
        System.out.println("F- Find Slip Details");
        System.out.println("V- View MMS Report");
        System.out.println("A- Archive MMS Report");
        System.out.println("R- Retrieve MMS Report");
        System.out.println("S- Show MMS Log");
        System.out.println("X- Close");
    }

    private void findSlipDetails() {
        String name = Utils.string("Name");
        MMSlip mmSlip = mmSlipWithName(name);
        if(mmSlip != null) {
            Utils.slipHeader();
            mmSlip.findSlipDetails();
            Utils.slipTableEnd();
        }
        else {
            System.out.println("Slip details does not exist for " + name + "!");
        }
    }

    private MMSlip mmSlipWithName(String name) {
        for(MMSlip mmSlip : mmSlips) {
            if(mmSlip.hasName(name)) {
                return mmSlip;
            }
        }
        return null;
    }

    public void viewMMSReport() {
        Utils.Totalslipheader();
        for(MMSlip mmSlip : mmSlips) {
            mmSlip.findSlipDetails();
        }
        Utils.TotalslipTableEnd();
        System.out.println();
        Utils.TotalSumHeader();
        viewStatistics();
        Utils.TotalSumTableEnd();
    }

    private void viewStatistics() {
        System.out.format(Utils.sumFormat, "Total expense", this.expense);
        System.out.format(Utils.sumFormat, "Total credits", this.totalCredits);
        System.out.format(Utils.sumFormat, "Total dollars", this.dollarAvailable);
        System.out.format(Utils.sumFormat, "Average pay per credit", average(this.payPerCredit));
        System.out.format(Utils.sumFormat, "Average deduction rate", average(this.deductionRate));
        System.out.format(Utils.sumFormat, "Average gas deduction rate", average(this.gasDeductionRate));
    }
    
    private double average(double sum) {
        return sum / memberships.getSize();
    }

    private void archiveMMSReport() {
        superMarket.archiveMMSReport(superMarket, memberships);
    }

    private void showMMSLog() {
        Utils.logHeader();
        superMarket.showMMSLog(superMarket);
        Utils.LogTableEnd();
    }

    private void retrieveMMSReport() {
        String recordID = Utils.string("RecordID");
        MMS mms = superMarket.mms(recordID, superMarket);
        if(mms != null) {
            superMarket.retrieveMMSReport(mms);
        }
        else {
            System.out.println("No MMS is recorded as: " + recordID);
        }
    }

    @Override
    public String toString() {
        return "" + mmSlips;
    }

}
